from rest_framework import serializers
from django.db import models

class QuestionSerializer(serializers.Serializer):
    question = serializers.CharField(max_length=256,allow_blank=True)
    answer = serializers.JSONField()

    class Meta:
        fields = ('question','answer')