from django.shortcuts import render
from .serializers import QuestionSerializer
from .classifier import Classifier
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

classifier = Classifier()

class QuestionCreate(APIView):
    """
    List all question and answer, or create a new question.
    """
    def get(self, request, format=None):
        answer = "I'm Prabhu Bank Assistants. I'm glad you choice me. What can i do for you?"
        data = {'question':None,'answer': answer}
        serializer = QuestionSerializer(data)
        return Response(serializer.data)

    def post(self, request, format=None):
        data = request.data['question']
        res = classifier.response(data)
        data = {'question':data,'answer':res}
        serializer = QuestionSerializer(data)

        return Response(serializer.data, status=status.HTTP_201_CREATED)

def index(request):
    return render(request, 'chat/new.html')