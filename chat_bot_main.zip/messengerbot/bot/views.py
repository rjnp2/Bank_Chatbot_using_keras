from django.shortcuts import render
from django.views.generic import View
from django.http.response import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
import re
import requests
import hmac
import hashlib
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

from .classifier import Classifier
from django.utils.decorators import method_decorator

# Create your views here.
PAGE_ACCESS_TOKEN = "EAAMr2mcGH5UBAPByx68ER9R8IceEPbkWZAkrMzifvw1EutywypkVm4r2Uo3VMrK4nYoZAJ0GPq55lGZCIecTEL7WkiAasZCX62sidZBGrGTcL0DfqwZBwzhEPjHmGmCtSSZBqmDZCvX7aibiV4113QyeoTIEIM4djkyhhFGAM4GZAx12nB2YBWkfF8ZA8zwsHSNnYZD"
VERIFY_TOKEN = "3b334d67912571727448393306"
APP_SECRET = "7d2cd927864625fa8c28cea26a3c6177"

classifier = Classifier()
stop_words = set(stopwords.words('english'))

# Helper function
def generate_appsecret_proof():
    """
    @outputs:
        appsecret_proof: HMAC-SHA256 hash of page access token
            using app_secret as the key
    """
    app_secret = str(APP_SECRET).encode('utf8')
    access_token = str(PAGE_ACCESS_TOKEN).encode('utf8')

    return hmac.new(app_secret, access_token, hashlib.sha256).hexdigest()


def send_messages(recipientid, data):
    """Send a response to Facebook"""
    payload = {
        'recipient': {
            'id': recipientid
        },
        "messaging_type": "RESPONSE",
        "notification_type": "REGULAR",
        'message': data
    }

    headers = {'Content-Type': 'application/json'}

    auth = {
        'access_token': PAGE_ACCESS_TOKEN,
        'appsecret_proof': generate_appsecret_proof()
    }

    # print(payload)
    URL = 'https://graph.facebook.com/v12.0/me/messages?access_token={}'.format(
        PAGE_ACCESS_TOKEN)

    response = requests.post(
        URL,
        params=auth,
        json=payload,
        headers=headers
    )
    print('resp', response.json())


def post_facebook_message(recipientid, recevied_message):
    # Remove all punctuations, lower case the text and split it based on space
    tokens = re.sub(r"[^a-zA-Z0-9\s?.]", ' ', recevied_message).lower()
    tokens = ''.join(x for x in tokens)
    res = classifier.response(tokens)

    print('res:', res)

    if "context" in res:
        text = res['context'].replace('\n', ' ').strip()
        text = text.replace('<br>', '\n')
        if "link" in res:
            if isinstance(res['link'], list):
                url_name = res['link'][0]
                url = res['link'][1]
            else:
                url_name = "Url link"
                url = res['link']
            data = {
                "attachment": {
                    "type": "template",
                    "payload": {
                        "template_type": "button",
                        "text": text,
                        "buttons": [
                            {
                                "type": "web_url",
                                "url": url,
                                "title": url_name,
                                "webview_height_ratio": "full"
                            }]}
                }}
        else:
            data = {
                'text': text
            }
        send_messages(recipientid, data)

    if "options" in res:
        text = ''
        elements = []
        for option in res['options']:
            if isinstance(option, list):
                elements.append({
                    "title": option[0],
                    "image_url": "https://play-lh.googleusercontent.com/B_vXZ4UUXc242bE-mFHIst69QUA3bPnzANcd6piCjBW7aas3mKpeC4Fsj_4tBkmvS7c=s180-rw",
                    "subtitle": option[1],
                    "default_action": {
                        "type": "web_url",
                        "url": option[2],
                        "webview_height_ratio": "tall"},
                    "buttons": [
                        {"type": "web_url",
                         "url": option[2],
                         "title":"For More"}
                    ]})
            else:
                text += option.capitalize() + "\n"

        if elements:
            data = {
                "attachment": {
                    "type": "template",
                    "payload": {
                        "template_type": "generic",
                        "elements": elements}}
            }

        elif text:
            data = {
                'text':text 
            }
        send_messages(recipientid, data)

    if 'similar' in res:
        quick_replies = []
        for similar in res['similar']:
            if len(similar.split()) < 4:
                quick_replies.append(
                    {
                    "content_type":"text",
                    "title":similar,
                    "payload":similar,
                    "image_url":""
                    })
            
            else:

                quick_replies.append(
                    {
                    "content_type":"text",
                    "title":' '.join([w for w in word_tokenize(similar) if not w.lower() in stop_words]),
                    "payload":similar,
                    "image_url":""
                    })
        
        if quick_replies:
            data = {
            "text": "Related Queries:",
            "quick_replies":quick_replies}

        send_messages(recipientid, data)
    return

class YoMamaBotView(View):
    @ method_decorator(csrf_exempt)  # required
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)  # python3.6+ syntax

    def get(self, request, *args, **kwargs):
        hub_mode = request.GET.get('hub.mode')
        hub_token = request.GET.get('hub.verify_token')
        hub_challenge = request.GET.get('hub.challenge')

        if hub_mode == 'subscribe' and hub_token == VERIFY_TOKEN:
            URL = 'https://graph.facebook.com/v12.0/me/messenger_profile?access_token={}'.format(
                PAGE_ACCESS_TOKEN)

            payload = {
                "get_started": {
                    'payload': 'Get Started'},

                "greeting": [{
                    "locale": "default",
                    "text": "Hello! {{user_full_name}}"
                }, {
                    "locale": "en_US",
                    "text": "Timeless apparel for the masses."
                }],
                "persistent_menu": [
                    {
                        "locale": "default",
                        "composer_input_disabled": False,
                        "call_to_actions": [
                            {
                                "type": "postback",
                                "title": "Talk to an agent",
                                "payload": "CARE_HELP"
                            },
                            {
                                "type": "postback",
                                "title": "Outfit suggestions",
                                "payload": "CURATION"
                            },
                            {
                                "type": "web_url",
                                "title": "Shop now",
                                "url": "https://www.originalcoastclothing.com/",
                                "webview_height_ratio": "full"
                            }]
                    }]}

            auth = {
                'access_token': PAGE_ACCESS_TOKEN,
                'appsecret_proof': generate_appsecret_proof()
            }

            response = requests.post(
                URL,
                params=auth,
                json=payload,
                headers={'Content-Type': 'application/json'}
            )
            print(response.json())

            return HttpResponse(hub_challenge, status=200)
        return HttpResponse('Error, invalid token', status=403)

    # Post function to handle Facebook messages
    def post(self, request, *args, **kwargs):

        # Converts the text payload into a python dictionary
        incoming_message = json.loads(request.body.decode('utf-8'))

        # Facebook recommends going through every entry since they might send
        # multiple messages in a single call during high load
        for entry in incoming_message['entry']:
            print('entry', entry)

            for message in entry['messaging']:
                # Check to make sure the received call is a message call
                # This might be delivery, optin, postback for other events
                sendid = message['sender']['id']

                if message.get('account_linking'):
                    pass

                elif message.get('postback'):
                    # Print the message to the terminal
                    if 'payload' in message['postback']:
                        print('message:', message['postback']['payload'])
                        message = message['postback']['payload']
                        if message == 'Get Started':
                            message = "Menu"
                        # Assuming the sender only sends text. Non-text messages like stickers, audio, pictures
                        # are sent as attachments and must be handled accordingly.
                        post_facebook_message(
                            sendid, message)

                elif message.get('delivery'):
                    """Method to handle `message_deliveries`"""
                    pass

                elif message.get('message'):
                    # Print the message to the terminal
                    # Print the message to the terminal
                    if 'quick_reply' in message['message']:
                        print('message:', message['message']['quick_reply']['payload'])
                        # Assuming the sender only sends text. Non-text messages like stickers, audio, pictures
                        # are sent as attachments and must be handled accordingly.
                        post_facebook_message(
                            sendid, message['message']['quick_reply']['payload'])

                    elif 'text' in message['message'] and not message['message'].get('is_echo'):
                        print('message:', message['message']['text'])
                        # Assuming the sender only sends text. Non-text messages like stickers, audio, pictures
                        # are sent as attachments and must be handled accordingly.
                        post_facebook_message(
                            sendid, message['message']['text'])

                elif message.get('optin'):
                    """Method to handle `messaging_optins`"""
                    pass
                elif message.get('postback'):
                    """Method to handle `messaging_postbacks`"""
                    pass
                elif message.get('read'):
                    """Method to handle `message_reads`"""
                    pass

        return HttpResponse(status=200)
