"# simple-inventory-management-system-in-django" 
