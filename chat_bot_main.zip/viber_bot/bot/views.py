from viberbot.api.messages import (VideoMessage, LocationMessage, KeyboardMessage, PictureMessage, RichMediaMessage,
                                   ContactMessage, URLMessage, FileMessage, KeyboardMessage)
from viberbot.api.viber_requests import ViberConversationStartedRequest
from viberbot.api.viber_requests import ViberUnsubscribedRequest
from viberbot.api.messages.data_types.location import Location
from viberbot.api.messages.data_types.contact import Contact
from viberbot.api.viber_requests import ViberSubscribedRequest
from viberbot.api.bot_configuration import BotConfiguration
from viberbot.api.messages.text_message import TextMessage
from viberbot.api.viber_requests import ViberFailedRequest
from viberbot.api.viber_requests import ViberMessageRequest
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.http.response import HttpResponse
from django.shortcuts import render
from django.views.generic import View
from .classifier import Classifier
from viberbot import Api
import requests
import logging
import json
import re
import time

classifier = Classifier()

# Create your views here.
bot_configuration = BotConfiguration(
    name='rjn bot',
    avatar='',
    auth_token='4e75caec39e7e3d3-a16a646eef8a4927-5cc7e21ef4dd3f02'
)
viber = Api(bot_configuration)

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# Helper function
def post_viber_message(sender_id, recevied_message):
    # Remove all punctuations, lower case the text and split it based on space
    tokens = re.sub(r"[^a-zA-Z0-9\s?.]", ' ', recevied_message).lower()
    res = classifier.response(tokens)
    print('res',res)

    if "context" in res:
        text = res['context'].replace('<br>', ' ').replace('\n', ' ').strip()
       
        if "link" in res:
            if isinstance(res['link'], list):
                text += '\n' + res['link'][1]
            else:
                text += '\n' + res['link']
        print('text',text)
        tokens = viber.send_messages(sender_id, messages=[TextMessage(text=text)])

    if "options" in res:
        buttons = []

        for option in res['options']:
            if isinstance(option, list):
                option = str(option[0]) 
            buttons.append({
                "Columns": 2,
                "Rows": 1,
                "BgColor": "#a1a1a1",
                "BgMedia": "https://play-lh.googleusercontent.com/B_vXZ4UUXc242bE-mFHIst69QUA3bPnzANcd6piCjBW7aas3mKpeC4Fsj_4tBkmvS7c=s180-rw",
                "BgMediaType": "picture",
                "BgLoop": "true",
                "ActionType": "reply",
                "ActionBody": option,
                "ReplyType": "message",
                "Text": f"<b>{option}</b>",
                "TextSize":"regular",
            })

        SAMPLE_KEYBOARD = {
            "Type": "keyboard",
            "Buttons": buttons
        }
        message = KeyboardMessage(tracking_data='tracking_data', keyboard=SAMPLE_KEYBOARD)
        tokens = viber.send_messages(sender_id, messages=[message])
        print(tokens)

    if 'similar' in res:
        buttons = []
        for similar in res['similar']:
            img = "https://play-lh.googleusercontent.com/B_vXZ4UUXc242bE-mFHIst69QUA3bPnzANcd6piCjBW7aas3mKpeC4Fsj_4tBkmvS7c=s180-rw"
            question_len = 6 if len(similar.split()) > 3 else 2
            BgMedia = '' if len(similar.split()) > 3 else img
            print(question_len)

            buttons.append({
                    "Columns": question_len,
                    "Rows": 1,
                    "BgColor": "#a1a1a1",
                    "BgMedia": BgMedia,
                    "BgMediaType": "picture",
                    "BgLoop": "true",
                    "ActionType": "reply",
                    "ActionBody": similar,
                    "ReplyType": "message",
                    "Text":  f"<b>{similar}</b>"
                })

        SAMPLE_KEYBOARD = {
            "Type": "keyboard",
            "Buttons": buttons
        }
        message = KeyboardMessage(tracking_data='tracking_data', keyboard=SAMPLE_KEYBOARD)
        tokens = viber.send_messages(sender_id, messages=[message])
        print(tokens)
    return 

class BotView(View):
    @ method_decorator(csrf_exempt)  # required
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)  # python3.6+ syntax

    def get(self, request, *args, **kwargs):
        pass

    # Post function to handle Facebook messages
    def post(self, request, *args, **kwargs):
        logger.debug("received request. post data: {0}".format(request.body))

        # every viber message is signed, you can verify the signature using this method
        if not viber.verify_signature(request.body, request.headers.get('X-Viber-Content-Signature')):
            return HttpResponse(status=403)

        # this library supplies a simple way to receive a request object
        viber_request = viber.parse_request(request.body)
        print('message', viber_request)

        if isinstance(viber_request, ViberMessageRequest):
            message = viber_request.message

            if isinstance(message, TextMessage):
                text = message.text
                sender_id = viber_request.sender.id

                post_viber_message(sender_id, text)

            elif isinstance(message, PictureMessage):
                # lets echo back
                image = message.media
                print('image', image)
                text = message.text
                print('image', text)

                # message = PictureMessage(media=image, text=text)
                viber.send_messages(viber_request.sender.id, messages=[
                    TextMessage(
                        text=f'Sorry I can\'t understand image, {viber_request.sender.name}')
                ])

            elif isinstance(message, LocationMessage):
                # lets echo back
                print(message)
                location = (message.location.latitude,
                            message.location.longitude)
                # location = message.location
                print('image', location)

                # location = Location(lat=location[0], lon=location[1])
                # message = LocationMessage(location=location)

                viber.send_messages(viber_request.sender.id, messages=[
                    TextMessage(
                        text=f'{viber_request.sender.name} live in {location}')
                ])

            elif isinstance(message, VideoMessage):
                # lets echo back
                print(message)
                video = message.media
                print('video', video)
                thumbnail = message.thumbnail
                print('thumbnail', thumbnail)
                size = message.size
                print('size', size)
                duration = message.duration
                print('duration', duration)
                text = message.text
                print('text', text)

                # message = VideoMessage(media=video, size=size, thumbnail=thumbnail, duration=duration, text=text)

                viber.send_messages(viber_request.sender.id, messages=[
                    TextMessage(
                        text=f'{viber_request.sender.name} send video to me.')
                ])

            elif isinstance(message, ContactMessage):
                # lets echo back
                message = message.contact
                print(message)
                name = message.name
                print('name', name)
                phone_number = message.phone_number
                print('thumbnail', phone_number)
                avatar = message._avatar
                print('size', avatar)

                # message = VideoMessage(media=video, size=size, thumbnail=thumbnail, duration=duration, text=text)

                viber.send_messages(viber_request.sender.id, messages=[
                    TextMessage(
                        text=f'Contact info is name={name}, phone_number={phone_number}')
                ])

            elif isinstance(message, URLMessage):
                # lets echo back
                print(message)
                url = message.media
                print('url', url)

                # message = URLMessage(media= url);

                viber.send_messages(viber_request.sender.id, messages=[
                    TextMessage(text=f'Contact info is name={url}')
                ])

            elif isinstance(message, FileMessage):

                # lets echo back
                print(message)
                url = message.media
                print('url', url)
                size = message.size
                print('size', size)
                file_name = message.file_name
                print('url', file_name)

                # message = FileMessage(media=url, size=size, file_name=file_name)

                viber.send_messages(viber_request.sender.id, messages=[
                    TextMessage(
                        text=f'File info is name={url}, size={size}, file_name={file_name}')
                ])

            elif isinstance(message, RichMediaMessage):

                # lets echo back
                SAMPLE_RICH_MEDIA = {
                    "BgColor": "#69C48A",
                    "Buttons": [{
                        "Columns": 6,
                        "Rows": 1,
                        "BgMediaType": "gif",
                        "BgMedia": "http://www.url.by/test.gif",
                        "BgLoop": "true",
                        "ActionType": "open-url",
                        "Silent": "true",
                        "ActionBody": "",
                        "Image": "www.tut.by/img.jpg",
                        "TextVAlign": "middle",
                        "TextHAlign": "left",
                        "Text": "<b>example</b> button",
                        "TextOpacity": 10,
                        "TextSize": "regular"
                    }]}

                SAMPLE_ALT_TEXT = "upgrade now!"

                message = RichMediaMessage(
                    min_api_version=7, rich_media=SAMPLE_RICH_MEDIA, alt_text=SAMPLE_ALT_TEXT)

                Viber.send_messages(viber_request.sender.id, messages=[message
                                                                       ])

            elif isinstance(message, KeyboardMessage):

                SAMPLE_KEYBOARD = {
                    "Type": "keyboard",
                    "Buttons": [
                        {
                            "Columns": 1,
                            "Rows": 2,
                            "BgColor": "#e6f5ff",
                            "BgMedia": "http://link.to.button.image",
                            "BgMediaType": "picture",
                            "BgLoop": True,
                            "ActionType": "reply",
                            "ActionBody": "This will be sent to your bot in a callback",
                            "ReplyType": "message",
                            "Text": "Push me!"
                        },
                        {
                            "Columns": 2,
                            "Rows": 2,
                            "BgColor": "#e6f5ff",
                            "BgMedia": "http://link.to.button.image",
                            "BgMediaType": "picture",
                            "BgLoop": True,
                            "ActionType": "reply",
                            "ActionBody": "This will be sent to your bot in a callback",
                            "ReplyType": "message",
                            "Text": "Push me!"
                        },
                        {
                            "Columns": 3,
                            "Rows": 2,
                            "BgColor": "#e6f5ff",
                            "BgMedia": "http://link.to.button.image",
                            "BgMediaType": "picture",
                            "BgLoop": True,
                            "ActionType": "reply",
                            "ActionBody": "This will be sent to your bot in a callback",
                            "ReplyType": "message",
                            "Text": "Push me!"
                        }
                    ]
                }

                message = KeyboardMessage(
                    tracking_data='tracking_data', keyboard=SAMPLE_KEYBOARD)

                viber.send_messages(viber_request.sender.id, messages=[
                    message
                ])

        elif isinstance(viber_request, ViberSubscribedRequest):
            viber.send_messages(viber_request.user.id, [
                TextMessage(
                    text=f"thanks for subscribing! {viber_request.user.name}")
            ])
        elif isinstance(viber_request, ViberFailedRequest):
            logger.warn(
                "client failed receiving message. failure: {0}".format(viber_request))

        return HttpResponse(status=200)
