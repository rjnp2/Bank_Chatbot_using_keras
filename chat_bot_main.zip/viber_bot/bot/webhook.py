from viberbot.api.bot_configuration import BotConfiguration
from viberbot import Api

bot_configuration = BotConfiguration(
	name='rjn bot',
	avatar='',
	auth_token='4e75caec39e7e3d3-a16a646eef8a4927-5cc7e21ef4dd3f02'
)
viber = Api(bot_configuration)
viber.set_webhook('https://2a8c-124-41-198-236.ngrok.io:443')
