from django.test import TestCase

# Create your tests here.
# b'{"event":"webhook","timestamp":1640142278043,"chat_hostname":"SN-CHAT-07_","message_token":5654276218722605448}'