# Libraries needed for Tensorflow processing
from sklearn.metrics.pairwise import cosine_similarity
import tensorflow as tf
import tensorflow_hub as hub
import pickle
import numpy as np
import random
import json
import pandas as pd

# Just disables the warning, doesn't take advantage of AVX/FMA to run faster
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
# os.environ["TFHUB_CACHE_DIR"] = "C:/Users/rjnp2/Desktop/chatbot/files/"

class Classifier():

    def __init__(self):

        # restoring all the data structures
        data_file = pickle.load(
            open("C:/Users/rjnp2/Desktop/chat_bot_main/viber_bot/files/training_data", "rb"))
        self.classes = data_file['classes']
        self.data = data_file['data']

        self.model = tf.keras.models.load_model('C:/Users/rjnp2/Desktop/chat_bot_main/viber_bot/files/chatbot_model.h5')

        # self.inter_output_model = tf.keras.Model(
        #     self.model.input, self.model.get_layer(index=0).output)

        self.use_model = hub.load('C:/Users/rjnp2/Desktop/chat_bot_main/viber_bot/files/universal-sentence-encoder-large_5')

        self.dataframe = pd.read_csv('C:/Users/rjnp2/Desktop/chat_bot_main/viber_bot/files/ne_FAQ.csv')

        self.sentence_emb = self.use_model(self.dataframe["Question"].astype(str).values.tolist())

    def response(self, sentence):
        emb = self.use_model([sentence])
        a = self.model.predict(emb)[0]
        pro = np.max(a)
        class_name = self.classes[np.argmax(a)]

        if pro > 0.45:

            if class_name == 'queries':
                
                cos_sim = cosine_similarity(emb, self.sentence_emb)[0]
                max_cos_sim_value = np.max(cos_sim)

                if max_cos_sim_value > 0.8:
                    max_cos_sim = cos_sim.argsort()[-1:][0]
                    sim_cos_sim = cos_sim.argsort()[-8:-4][::-1]

                    cos_sim = cos_sim[max_cos_sim]

                    answer = self.dataframe.iloc[max_cos_sim].Answer

                    answer = {
                                "context": answer,
                        }
                    return answer

                elif max_cos_sim_value > 0.45:
                    max_cos_sim = cos_sim.argsort()[-3:][::-1]
                    cos_sim = cos_sim[max_cos_sim]
                    simple_que = self.dataframe.iloc[max_cos_sim].Question.values

                    return {
                                "context": "find similar question",
                                "similar": simple_que
                        }
                    # return [ (pro, ques) for pro, ques in zip(cos_sim, simple_que)]
                
                else:
                    return {"context": "Sorry, no result found. Please contact to your nearest bank branch. Thank You."}

            else:
                return self.data[class_name]
      
        else:
            return {"context": "Sorry, I can't understand you."}